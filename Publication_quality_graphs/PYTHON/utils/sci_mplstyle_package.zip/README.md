**style file for scientific visualization.**

"pip install ." to install the setup.py

If you decide to change an entry, feel free to open the mplstyle file in sci_mplstyle_pacakge/style_files

However, once you make the change, reinstall the package by re-running "pip install ." from the setup.py file directory.